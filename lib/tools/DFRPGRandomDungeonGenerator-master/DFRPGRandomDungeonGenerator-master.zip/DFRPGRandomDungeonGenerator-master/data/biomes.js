﻿var biomes = [
    {"Description": "Arctic", "Weight": 2},
    {"Description": "Desert", "Weight": 2},
    { "Description": "Island", "Weight": 1 },
    { "Description": "Beach", "Weight": 1 },
    {"Description": "Jungle", "Weight": 2},
    {"Description": "Mountain", "Weight": 2},
    {"Description": "Plains", "Weight": 2},
    {"Description": "Swampland", "Weight": 2},
    {"Description": "Woodlands", "Weight": 2}
];