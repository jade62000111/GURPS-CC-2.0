﻿var smellsNumber = [
  {
    "Weight": 6,
    "Description": 0,
    "Tables": ""
  },
  {
    "Weight": 1,
    "Description": 1,
    "Tables": "smells"
  }
];