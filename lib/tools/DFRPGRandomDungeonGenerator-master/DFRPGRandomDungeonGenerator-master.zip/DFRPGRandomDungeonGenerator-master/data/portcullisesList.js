var portcullisesList = [
    {
      "Weight": 11,
      "Description": "Iron-bound oak portcullis: DR 6; HP 12; 200 lbs; ST 12 to lift 2-handed (4 seconds)"
    },
    {
      "Weight": 9,
      "Description": "Light iron portcullis: DR 9; 18 HP; 500 lbs; ST 18 to lift 2-handed (4 seconds)"
    },
    {
      "Weight": 6,
      "Description": "Heavy iron portcullis: DR 12; HP 23; 1000 lbs; ST 25 to lift 2-handed (4 seconds)"
    },
    {
      "Weight": 4,
      "Description": "Vault portcullis: DR 24; HP 46; 3000 lbs; ST 44 to lift 2-handed (4 seconds)"
    }
   ];