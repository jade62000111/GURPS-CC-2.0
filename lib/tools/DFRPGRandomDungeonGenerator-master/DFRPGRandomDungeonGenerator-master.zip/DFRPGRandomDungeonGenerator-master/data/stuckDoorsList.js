var stuckDoors = [
    {
      "Weight": 65,
      "Description": "It is a bit stuck (ST roll to force open)"
    },
    {
        "Weight": 35,
        "Description": "It is stuck (ST-2 roll to force open)"
    },
    {
        "Weight": 25,
        "Description": "It is really stuck (ST-4 roll to force open)"
    },
    {
        "Weight": 1,
        "Description": "It is seriously jamned (ST-6 roll to force open)"
    }
   ];