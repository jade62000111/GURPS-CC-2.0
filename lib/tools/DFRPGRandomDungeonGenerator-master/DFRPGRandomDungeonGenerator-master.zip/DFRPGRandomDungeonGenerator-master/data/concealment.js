﻿var concealment = [
  {
    "Weight": 5,
    "Description": "Concealed behind a tapestry: Search -1"
  },
  {
    "Weight": 5,
    "Description": "Concealed behind furniture: Search -1"
  },
  {
    "Weight": 14,
    "Description": "Simply concealed in room construction: Search -2"
  },
  {
    "Weight": 29,
    "Description": "Simply concealed in room construction, and behind tapestries: Search -3"
  },
  {
    "Weight": 25,
    "Description": "Simply concealed in room construction, and behind furniture: Search -3"
  },
  {
    "Weight": 24,
    "Description": "Expertly concealed in room construction (e.g. swinging book-case/fireplace mantle): Search -4"
  },
  {
    "Weight": 9,
    "Description": "Expertly concealed in wall construction, and behind tapestries: Search -6"
  },
  {
    "Weight": 9,
    "Description": "Expertly concealed in wall construction, and behind a relief sculpture: Search -6"
  },
  {
    "Weight": 14,
    "Description": "Expertly concealed in wall construction, and behind furniture: Search -6"
  },
  {
    "Weight": 9,
    "Description": "Masterfully concealed in wall construction (rotating wall segment), behind tapestries: Search -8"
  },
  {
    "Weight": 9,
    "Description": "Masterfully concealed in wall construction (rotating wall segment), behind furniture: Search -8"
  },
  {
    "Weight": 2,
    "Description": "Masterfully concealed in wall construction (rotating wall segment), behind an elaborate artistic relief: Search -10"
  },
  {
    "Weight": 2,
    "Description": "Masterfully concealed in wall construction (rotating wall segment), in an elaborate wall fresco: Search -10"
  },
  {
    "Weight": 4,
    "Description": "Masterfully concealed in wall construction (rotating wall segment), behind large, heavy furniture: Search -10"
  }
];