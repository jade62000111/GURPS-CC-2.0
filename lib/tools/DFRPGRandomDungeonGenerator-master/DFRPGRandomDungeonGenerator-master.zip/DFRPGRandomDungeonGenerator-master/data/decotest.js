﻿var decorations = [
    {
        "Weight": 20,
        "Description": "There is an alcove"
    },
    {
        "Weight": 5,
        "Description": "There is an altar"
    },
    {
        "Weight": 1,
        "Description": "There is an arch"
    }
];