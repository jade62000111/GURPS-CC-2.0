﻿var poison = [
    {
        "Weight": 1,
        "Description": "TEST POISON. Kills you dead."
    }
];