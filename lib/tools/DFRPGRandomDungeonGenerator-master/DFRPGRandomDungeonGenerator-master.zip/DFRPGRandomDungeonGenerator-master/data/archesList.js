var archesList = [
    {
      "Weight": 5,
      "Description": "An open doorframe"
    },
    {
      "Weight": 20,
      "Description": "A peaked archway"
    },
    {
      "Weight": 20,
      "Description": "A squared archway"
    },
    {
        "Weight": 20,
        "Description": "A rounded archway"
    },
    {
      "Weight": 4,
      "Description": "A broken door hanging half off its hinges"
    },
    {
        "Weight": 4,
        "Description": "A doorway littered with shattered oak boards"
    },
    {
        "Weight": 4,
        "Description": "A doorway littered with rotting oak boards"
    },
    {
        "Weight": 4,
        "Description": "A doorway where a door once hung, now only the hinges remain"
    },
    {
        "Weight": 1,
        "Description": "A squared archway and the wreckage of an iron portcullis"
    },
    {
        "Weight": 1,
        "Description": "A peaked archway and the wreckage of an iron portcullis"
    },
    {
        "Weight": 1,
        "Description": "A rounded archway and the wreckage of an iron portcullis"
    },
    {
        "Weight": 1,
        "Description": "A squared archway and the rusty wreckage of an iron portcullis"
    },
    {
        "Weight": 1,
        "Description": "A peaked archway and the rusty wreckage of an iron portcullis"
    },
    {
        "Weight": 1,
        "Description": "A rounded archway and the rusty wreckage of an iron portcullis"
    }
   ];