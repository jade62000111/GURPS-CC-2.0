﻿var decorationNumber = [
    {
        "Weight": 50,
        "Description": 1,
        "Tables": "decorations"
    },
    {
        "Weight": 50,
        "Description": 2,
        "Tables": "decorations"
    },
    {
        "Weight": 50,
        "Description": 3,
        "Tables": "decorations"
    },
    {
        "Weight": 10,
        "Description": 4,
        "Tables": "decorations"
    },
    {
        "Weight": 3,
        "Description": 5,
        "Tables": "decorations"
    },
    {
        "Weight": 1,
        "Description": 6,
        "Tables": "decorations"
    }
];