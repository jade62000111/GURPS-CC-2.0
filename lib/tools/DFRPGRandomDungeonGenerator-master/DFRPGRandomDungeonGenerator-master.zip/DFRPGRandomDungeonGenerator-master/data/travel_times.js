﻿var travel_times = [
    {
        Type: "short",
        Weight: 7
    },
    
    {
        Type: "mid",
        Weight: 25
    },
    {
        Type: "long",
        Weight: 15
    },
    {
        Type: "super_far",
        Weight: 1
    }
];
