﻿var ceilings = [
    {
        "Weight": 1,
        "Description": "Low",
        "Height": 4
    },
    {
        "Weight": 1,
        "Description": "Low",
        "Height": 4.5
    },
    {
        "Weight": 1,
        "Description": "Low",
        "Height": 5
    },
    {
        "Weight": 2,
        "Description": "Moderate",
        "Height": 6
    },
    {
        "Weight": 4,
        "Description": "Moderate",
        "Height": 6.5
    },
    {
        "Weight": 6,
        "Description": "Moderate",
        "Height": 7
    },
    {
        "Weight": 6,
        "Description": "Moderate",
        "Height": 7.5
    },
    {
        "Weight": 6,
        "Description": "Moderate",
        "Height": 8
    },
    {
        "Weight": 5,
        "Description": "High",
        "Height": 9
    },
    {
        "Weight": 3,
        "Description": "High",
        "Height": 10
    },
    {
        "Weight": 3,
        "Description": "High",
        "Height": 12
    },
    {
        "Weight": 1,
        "Description": "Cavernous",
        "Height": 15
    },
    {
        "Weight": 1,
        "Description": "Cavernous",
        "Height": 20
    }
];