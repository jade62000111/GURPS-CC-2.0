﻿CREDIT:

This project is significantly based on version 1.0.3 of the random dungeon generator created by drow [drow@bin.sh] http://donjon.bin.sh
We owe drow a significant debt of gratitude. Thank you for making this work possible.

Modifications and elaborations by Emily Smirle and Kyle Norton.

This project is licensed under Creative Commons BY-NC 3.0
http://creativecommons.org/licenses/by-nc/3.0/

GURPS is a trademark of Steve Jackson Games, and its rules and art are copyrighted by Steve Jackson Games. 
All rights are reserved by Steve Jackson Games. 
This game aid is the original creation of Emily Smirle and Kyle Norton and is released for free distribution, 
and not for resale, under the permissions granted in the <a href="http://www.sjgames.com/general/online_policy.html">Steve Jackson Games Online Policy</a>.